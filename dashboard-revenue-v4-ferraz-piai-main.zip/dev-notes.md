

# Pipeline - Pré-venda
12184216

## Status ID

PROSPECT: 99026876
TENTATIVA DE CONTATO: 94128176
Conectado: 98005364
Reunião Agendada: 98005368
Venda ganha: 142
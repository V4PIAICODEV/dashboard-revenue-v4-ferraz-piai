Marque com X aquelas que já foram realizadas

## Header

[X] Ajustar: "Atualizado em: 05/02/2026, 00:33:00". A data deve ser pega de acordo com o último dia de update_at registrado
[X] Trocar: SALES MONITOR; Por: SALES MONITOR | Funil de Pré-vendas


## Funil de Pré-vendas

[X] Trocar: Venda Ganha; Por: Reunião Realizada

[X] Trocar: Conversão Total (Prospect → Venda); Por: Conversão Total (Prospect → Reunião Realizada)

## Resumo de Alertas

[X] Ajustar legenda para se adequar as regras. OBS: regras de formatação estão corretas, basta ajustar a legenda

## Performance SDR por Canal (Realizadas / Conv.)
[X] Trocar: Performance SDR por Canal (Realizadas / Conv.); Por: Performance SDR por Canal (Prospect -> Realizada)

## Ciclo de Reunião Realizada

[X] Se ciclo estiver acima da meta, destacar em vermelho

## Análise de Perdas

[X] Ao passar o mouse em cima das barras, mostrar número absoluto

## Distribuição BANT por SDR

[X] Na parte de distribuição, na coluna que possui uma barra com cores, mostre o absoluto e percentual ao passar o mouse por cima para ver o detalhamento

## Filtro

[X] Remover filtro de canal
[X] Remover filtro de SDR
[X] Remover botão de filtrar